package com.example.votesapp.activities.registro_usuario;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.votesapp.R;

public class Registro_usuario extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro_usuario);
    }
}